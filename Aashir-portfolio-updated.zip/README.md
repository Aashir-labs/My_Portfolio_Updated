# Aashir Ahmed — Portfolio

**Brand Manager · Social Media Strategist · Digital Growth**
📍 Karachi, Pakistan

---

## 🔗 Live Portfolio

- Netlify: https://aashir-ahmed-portfolio.netlify.app
- GitHub Pages: https://aashir-labs.github.io/Aashir-portfolio

---

## 🗂 Project Structure

```
/index.html          ← main site (single page, anchor navigation)
/v2.html             ← legacy alternate draft (not linked from index.html)
/css/style.css       ← all styling
/js/data.js          ← ALL editable content lives here (experience, services, projects)
/js/main.js          ← rendering + interactions (filtering, modal, nav, animations)
/assets/
  images/
    profile/         ← headshot
    social-media/    ← social media management work
    meta-ads/        ← Meta Ads campaign screenshots/results
    brand-creative/  ← brand & creative direction work
    ai-creative/     ← AI-generated creative work
  videos/            ← reels / video deliverables
```

## ✏️ How to add a new project

Open `js/data.js`, find the `PROJECTS` array, and copy an existing
object as a template. Set:
- `id` — unique slug
- `category` — one of `social-media`, `meta-ads`, `brand-creative`, `ai-creative`
- `thumbnail` / `gallery` — paths to images inside `assets/images/<category>/`
- the rest of the case-study fields (challenge, strategy, execution, creativeWork, results)

Drop your image/video files into the matching `assets/` subfolder, save `data.js`,
and the new project card + case-study modal appear automatically on the Work page —
no HTML editing required.

## 🛠️ Skills

- Brand Management & Positioning
- Social Media Management (Instagram, Facebook, TikTok, YouTube)
- Meta Ads Manager (Facebook & Instagram Ads)
- Content Strategy & Content Calendar Planning
- Community Management & Audience Growth
- Performance Analytics (GA4, Meta Business Suite)
- Content Creation (Canva, CapCut, InShot)
- Scheduling Tools (Hootsuite, Buffer, Sprout Social)

## 💼 Experience

| Company | Role | Period |
|---------|------|--------|
| Technest | Brand Manager | 2026 – Present |
| 4Orbits | Social Media Manager | Oct 2025 – Present |
| Tijarat News | Social Media Manager | Dec 2024 – Sep 2025 |
| Imtiaz | Officer Marketing & Promotion | Feb 2022 – Sep 2024 |
| HM Communication | Social Media Executive | Feb 2021 – Dec 2021 |

## 📬 Contact

- 📧 Email: aashir.khan440@gmail.com
- 💬 WhatsApp: +92 310 2581680
- 🔗 Contra: https://contra.com/tijarat_team_pr39bgk7

---

*Built with HTML, CSS & JavaScript — no frameworks, no build step.
Deploys to Netlify directly from this repo's root — no build command required.*
